#!/usr/bin/env python3
import os
import cv2
import pandas as pd
import numpy as np
import time
from tqdm import tqdm

# Import your existing modules
from llm import EmotionalBot  # Ensure this points to the file containing the updated prompt
from emotion_buffer import shared_buffer
from qt_deep_face import QTDeepFace

def standardize_emotion(emo):
    """
    Standardizes structural naming variations to make comparisons scientifically valid.
    Maps everything to MELD's 7 base classes.
    """
    emo = str(emo).strip().lower()
    mapping = {
        'happy': 'joy',
        'joy': 'joy',
        'sad': 'sadness',
        'sadness': 'sadness',
        'fearful': 'fear',
        'fear': 'fear',
        'surprised': 'surprise',
        'surprise': 'surprise',
        'angry': 'anger',
        'anger': 'anger',
        'neutral': 'neutral',
        'calm': 'neutral',
        'disgust': 'disgust'
    }
    return mapping.get(emo, emo)

def normalize_window_data(window):
    """Duplicates the window normalization logic"""
    window_normalised = []
    for entry in window:
        normalised_entry = {}
        for emotion in entry:
            e = entry.get(emotion)
            if emotion == "timestamp":
                normalised_entry["timestamp"] = e
            elif emotion == "dominant":
                normalised_entry["dominant"] = e
            elif emotion == "confidence":
                normalised_entry["confidence"] = e
            elif emotion == 'scores':
                total = sum(e.values())
                if total == 0:
                    total = 1.0
                normalised_entry['scores'] = {score: round(value / total, 4) for score, value in e.items()}
        window_normalised.append(normalised_entry)
    return window_normalised

def format_window_for_classification(window):
    """Duplicates the window formatting logic"""
    if not window:
        return {"counts": {}, "averages": {}, "peaks": {}}
        
    emotion_counts = {}
    emotion_averages = {}
    emotion_peaks = {}
    for entry in window:
        dominant = entry.get("dominant")
        if dominant:
            emotion_counts[dominant] = emotion_counts.get(dominant, 0) + 1
        
        scores = entry.get("scores", {})
        for emotion, score in scores.items():
            emotion_averages[emotion] = emotion_averages.get(emotion, 0) + score
            if emotion not in emotion_peaks or score > emotion_peaks[emotion]:
                emotion_peaks[emotion] = score
    
    return {
        "counts": emotion_counts,
        "averages": {emotion: score / len(window) for emotion, score in emotion_averages.items()},
        "peaks": emotion_peaks
    }

def run_evaluation(csv_path, video_dir, models_list, num_samples=100):
    if not os.path.exists(csv_path):
        print(f"Error: Metadata CSV not found at {csv_path}")
        return
    
    df = pd.read_csv(csv_path)
    
    # MELD filename structure mapping
    df['video_filename'] = df.apply(lambda row: f"dia{row['Dialogue_ID']}_utt{row['Utterance_ID']}.mp4", axis=1)
    df['video_path'] = df.apply(lambda row: os.path.join(video_dir, row['video_filename']), axis=1)
    
    # Filter only rows where the video file successfully exists on disk
    df = df[df['video_path'].apply(os.path.exists)]
    
    if df.empty:
        print(f"Error: No matching video files found in {video_dir}")
        return

    sample_df = df.sample(n=min(num_samples, len(df)), random_state=42).copy()
    
    # ==========================================================
    # PHASE 1: PRECOMPUTE VISION (Run DeepFace Once for All Models)
    # ==========================================================
    print(f"\n[PHASE 1] Precomputing DeepFace vision processing for {len(sample_df)} clips...")
    detector = QTDeepFace(actions=['emotion'], detector_backend='ssd')
    
    cached_vision_data = []
    
    for idx, row in tqdm(sample_df.iterrows(), total=len(sample_df), desc="Processing Video Frames"):
        video_path = row['video_path']
        
        shared_buffer.entries.clear() 
        cap = cv2.VideoCapture(video_path)
        fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
        frame_interval = max(1, int(fps / 5))
        
        frame_idx = 0
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            if frame_idx % frame_interval == 0:
                detector.prev_proc_time = 0 
                try:
                    detector.analyze_face(frame)
                except Exception:
                    pass
            frame_idx += 1
        cap.release()
        
        raw_window = shared_buffer.get_window(start_time=0, end_time=time.time() + 10.0)
        normalized_window = normalize_window_data(raw_window)
        formatted_window = format_window_for_classification(normalized_window)
        
        counts = formatted_window.get("counts", {})
        if counts:
            deepface_pred = standardize_emotion(max(counts, key=counts.get))
        else:
            deepface_pred = "no_face"
            
        cached_vision_data.append({
            "formatted_window": formatted_window,
            "deepface_pred": deepface_pred
        })

    # ==========================================================
    # PHASE 2: BENCHMARK EACH MODEL
    # ==========================================================
    print(f"\n[PHASE 2] Starting LLM execution runs across {len(models_list)} models...")
    summary_matrix = []

    for model_name in models_list:
        print(f"\nExecuting benchmark for model: {model_name}")
        sanitized_filename = f"meld_eval_results_{model_name.replace(':', '_').replace('.', '_')}.csv"
        
        bot = EmotionalBot(model_name=model_name)
        model_results = []

        for i, (_, row) in enumerate(tqdm(sample_df.iterrows(), total=len(sample_df), desc=f"Running {model_name}")):
            transcript = row['Utterance']
            ground_truth = standardize_emotion(row['Emotion'])
            clip_id = row['video_filename']
            
            # Extract cached vision details
            formatted_window = cached_vision_data[i]["formatted_window"]
            deepface_pred = cached_vision_data[i]["deepface_pred"]
            
            # Branch A: Unimodal Test
            bot.reset()
            start_time = time.time()
            unimodal_res = bot.chat(transcript, deepface_data="")
            unimodal_latency = time.time() - start_time
            unimodal_pred = standardize_emotion(unimodal_res.classified_emotion)
            
            # Branch B: Multimodal Test
            bot.reset()
            start_time = time.time()
            multimodal_res = bot.chat(transcript, formatted_window)
            multimodal_latency = time.time() - start_time
            multimodal_pred = standardize_emotion(multimodal_res.classified_emotion)
            
            # Formatting Failure Logic (To defend smaller models in your paper)
            uni_format_fail = (unimodal_res.classified_emotion == "unknown")
            multi_format_fail = (multimodal_res.classified_emotion == "unknown")
            
            # Core evaluation comparisons
            df_correct = (deepface_pred == ground_truth)
            uni_correct = (unimodal_pred == ground_truth) and not uni_format_fail
            multi_correct = (multimodal_pred == ground_truth) and not multi_format_fail
            
            model_results.append({
                "Clip_ID": clip_id,
                "Transcript": transcript,
                "Ground_Truth": ground_truth,
                "DeepFace_Predicted": deepface_pred,
                "Unimodal_Predicted": unimodal_pred,
                "Multimodal_Predicted": multimodal_pred,
                "DeepFace_Correct": df_correct,
                "Unimodal_Correct": uni_correct,
                "Multimodal_Correct": multi_correct,
                "Unimodal_Format_Failed": uni_format_fail,
                "Multimodal_Format_Failed": multi_format_fail,
                "Multimodal_Mismatch_Detected": multimodal_res.mismatch_detected,
                "Unimodal_Latency_Sec": round(unimodal_latency, 3),
                "Multimodal_Latency_Sec": round(multimodal_latency, 3)
            })

        # Save specific model performance logs directly to their unique file track
        results_df = pd.DataFrame(model_results)
        results_df.to_csv(sanitized_filename, index=False)
        print(f"-> Saved individual CSV results to: {sanitized_filename}")
        
        # Calculate summary accuracy statistics
        df_acc = (results_df['DeepFace_Correct'].sum() / len(results_df)) * 100
        uni_acc = (results_df['Unimodal_Correct'].sum() / len(results_df)) * 100
        multi_acc = (results_df['Multimodal_Correct'].sum() / len(results_df)) * 100
        
        # Calculate format compliance rate
        uni_fail_rate = (results_df['Unimodal_Format_Failed'].sum() / len(results_df)) * 100
        multi_fail_rate = (results_df['Multimodal_Format_Failed'].sum() / len(results_df)) * 100
        
        avg_uni_lat = results_df['Unimodal_Latency_Sec'].mean()
        avg_multi_lat = results_df['Multimodal_Latency_Sec'].mean()
        
        summary_matrix.append({
            "Model": model_name,
            "DeepFace Acc.": f"{df_acc:.1f}%",
            "Unimodal Acc.": f"{uni_acc:.1f}%",
            "Multimodal Acc.": f"{multi_acc:.1f}%",
            "Uni Format Fail": f"{uni_fail_rate:.1f}%",
            "Multi Format Fail": f"{multi_fail_rate:.1f}%",
            "Avg Uni Latency": f"{avg_uni_lat:.2f}s",
            "Avg Multi Latency": f"{avg_multi_lat:.2f}s"
        })

    # Output a structured master table directly to terminal for easy dissertation copy-pasting
    summary_df = pd.DataFrame(summary_matrix)
    print(f"\n=========================================================================================")
    print(f"                          MASTER DISSERTATION COMPARISON MATRIX                          ")
    print(f"=========================================================================================")
    print(summary_df.to_string(index=False))
    print(f"=========================================================================================\n")

if __name__ == "__main__":
    import rospy
    
    # Initialize a dummy ROS node so rospy.get_time() works inside QTDeepFace
    rospy.init_node("meld_benchmark_node", anonymous=True)
    
    MELD_CSV = "MELD_dataset/train_sent_emo.csv" 
    MELD_VIDEOS = "MELD_dataset/train_splits"
    
    # Note: Keep the list small or sample size small for quick testing, expand for final overnight run.
    MODELS = [
        "gemma3:4b",
        "llama3.2:3b",
        "qwen2.5:3b",
        "granite3.2:2b",
        "smollm2:latest",
        "mistral:7b",
        "phi4-mini:latest"
    ]
    
    # Change num_samples=30 to a higher number (e.g. 100, 200) for your final formal test run
    run_evaluation(csv_path=MELD_CSV, video_dir=MELD_VIDEOS, models_list=MODELS, num_samples=100)
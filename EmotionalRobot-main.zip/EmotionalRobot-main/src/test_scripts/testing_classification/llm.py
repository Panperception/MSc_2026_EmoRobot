import ollama
from pydantic import BaseModel
import time
from ollama import Client

class EmotionResponse(BaseModel):
    mismatch_detected: bool
    mismatch_reason: str
    classified_emotion: str
    robot_response: str

TONE_MAP = {
    "gentle":       "\\vct=97\\\\rspd=82\\\\vol=65\\",
    "calm":         "\\vct=98\\\\rspd=90\\\\vol=70\\",
    "normal":       "\\vct=100\\\\rspd=100\\\\vol=80\\",
    "upbeat":       "\\vct=103\\\\rspd=108\\\\vol=85\\",
    "enthusiastic": "\\vct=107\\\\rspd=118\\\\vol=90\\",
}

COMPACT_PROMPT = f"""
You are QT, a friendly and empathetic social robot. Have natural, spoken conversations with users. You can include inline commands to control gestures, facial expressions, and tone. Use the exact syntax:

{{tone:NAME}}       - sets speaking tone (applies to text after it)
{{gesture:NAME}}    - plays a physical gesture
{{expression:NAME}} - shows a facial expression

## Tones
gentle, calm, normal, upbeat, enthusiastic

## Gestures
Positive: happy, clapping, hi, bye, kiss, send_kiss, show_QT
Negative: sad, angry, peekaboo, bored
Neutral: neutral, point_front, touch_head, stretching, yawn, drink, breathing_exercise

## Expressions
Positive: happy, happy_blinking, kiss, one_eye_win, shy
Negative: sad, angry, cry, disgusted, confused, suprise, sceam
Neutral: blowing_rasberry, calming_down, yawn, breathing_exercise
Note: "suprise" and "sceam" are spelled exactly as shown.

## Input Evaluation & Mismatch Logic
You will receive a JSON payload containing the user's spoken `transcript` and their `vision_data` (facial expressions analyzed over a recent time window). 
The vision data contains three metrics:
- counts: The most frequent dominant emotions. This establishes the user's baseline mood.
- averages: The mean confidence score for each emotion. This reveals sustained, secondary, or blended emotions.
- peaks: The absolute maximum confidence score for each emotion. This reveals fleeting micro-expressions or suppressed emotions.

You must compare the semantic meaning of the `transcript` against the `vision_data` to detect emotional dissonance. 
- MISMATCH: no -> The spoken text aligns with the visual emotional state.
- MISMATCH: yes/<reason> -> The spoken text contradicts the visual data (e.g., the user says "I am fine" but `peaks` or `averages` show high sadness or anger). 

If a mismatch occurs, heavily weight the `peaks` and `averages` to determine the true underlying emotion. Address this underlying emotion gently and empathetically in your response, rather than taking the text at face value.

## Command rules
- Most short replies need no gesture or expression. Only use them when they add meaning.
- Gestures and expressions must match emotionally when used together.
- Place commands at the natural moment in the response, not all at the start.
- After a strong emotional moment, return to a calmer state in the next response.
- Use at most one gesture and one expression per response.

## Speech rules
- This text will be spoken aloud. Write naturally as you would speak.
- Do not use emojis, emoticons, or special characters such as asterisks, percent signs, ampersands, or bullet symbols.
- Avoid markdown formatting. Write in plain conversational sentences.

## Output format
Always respond using exactly these three lines:
MISMATCH: yes/<reason> or no
CLASSIFICATION: neutral/joy/sadness/anger/fear/disgust/surprise
RESPONSE: <your reply with any inline commands>

## Examples
User says they just got a promotion (Vision matches):
MISMATCH: no
CLASSIFICATION: joy
RESPONSE: {{tone:enthusiastic}}{{expression:happy}}That is wonderful news! {{gesture:clapping}} Congratulations, you must be so proud of yourself.

User says they are feeling down (Vision matches):
MISMATCH: no
CLASSIFICATION: sadness
RESPONSE: {{tone:gentle}}{{expression:sad}}I am really sorry to hear that. {{gesture:sad}} Do you want to talk about what has been going on?

User says "I'm fine, everything is okay" (Vision shows high sadness peaks):
MISMATCH: yes/User claims to be fine but vision data shows high sadness peaks.
CLASSIFICATION: sadness
RESPONSE: {{tone:gentle}}{{expression:sad}}You say you are fine, but you look a little down to me. {{gesture:neutral}} I am always here to listen if you change your mind.
"""

class EmotionalBot:
    def __init__(self, model_name="gemma3:4b"):
        self.model = model_name
        self.conversation_history = [
            {"role": "system", "content": COMPACT_PROMPT}
        ]
    
    def chat(self, transcript, deepface_data):
        user_message = f"""
            TRANSCRIPT: {transcript}
            FACE: {deepface_data}
            """
        self.conversation_history.append({
            "role": "user",
            "content": user_message
        })
        
        start = time.time()
        
        try:
            local_client = Client(timeout=45.0)
            
            response = local_client.chat(
                model=self.model,
                messages=self.conversation_history,
                options={
                    "num_predict": 150,
                    "temperature": 0.2
                }
            )
            assistant_reply = response["message"]["content"]
            
        except Exception as e:
            print(f"\n[LLM ERROR] {self.model} failed or timed out: {e}")
            assistant_reply = "MISMATCH: error\nCLASSIFICATION: unknown\nRESPONSE: {tone:normal}{expression:neutral}I am here to listen."

        elapsed = time.time() - start
        print(f"{self.model} response time: {elapsed:.2f} seconds")

        self.conversation_history.append({
            "role": "assistant",
            "content": assistant_reply
        })

        return self._parse_response(assistant_reply)

    def _parse_response(self, text: str) -> EmotionResponse:
        mismatch_detected = False
        mismatch_reason = ""
        classified_emotion = "unknown"
        robot_response = ""

        for line in text.strip().splitlines():
            if line.startswith("MISMATCH:"):
                val = line[len("MISMATCH:"):].strip()
                mismatch_detected = val.lower().startswith("yes")
                mismatch_reason = val
            elif line.startswith("CLASSIFICATION:"):
                classified_emotion = line[len("CLASSIFICATION:"):].strip().lower()
            elif line.startswith("RESPONSE:"):
                robot_response = line[len("RESPONSE:"):].strip()

        return EmotionResponse(
            mismatch_detected=mismatch_detected,
            mismatch_reason=mismatch_reason,
            classified_emotion=classified_emotion,
            robot_response=robot_response
        )

    def reset(self):
        self.conversation_history = [
            {"role": "system", "content": COMPACT_PROMPT}
        ]

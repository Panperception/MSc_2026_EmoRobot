import os
import re
import cv2
import pandas as pd
from tqdm import tqdm
from deepface import DeepFace

# Import your custom LLM bot
from llm import EmotionalBot

# List of LLMs targeted for cross-comparison benchmarks
MODELS_TO_TEST = [
    "gemma3:4b",
    "llama3.2:3b",
    "qwen2.5:3b",
    "granite3.2:2b",
    "smollm2:latest",
    "mistral:7b",
    "phi4-mini:latest"
]

COMMAND_RE = re.compile(r'\{(tone|gesture|expression):([^}]+)\}')

def extract_llm_commands(response_text):
    """Parses inline commands chosen by the LLM response."""
    found_commands = {"tone": None, "gesture": None, "expression": None}
    matches = COMMAND_RE.findall(response_text)
    for cmd_type, cmd_value in matches:
        if cmd_type in found_commands:
            found_commands[cmd_type] = cmd_value
    return found_commands

def process_video_face_data(video_path):
    """Processes 3 anchor frames from the video and mirrors robot normalization."""
    if not os.path.exists(video_path):
        return []
        
    cap = cv2.VideoCapture(video_path)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    window_entries = []

    # Optimization: Extract 3 structural anchor frames (start, middle, end)
    if total_frames > 3:
        sample_frames = [int(total_frames * 0.2), int(total_frames * 0.5), int(total_frames * 0.8)]
    else:
        sample_frames = [0]

    for frame_target in sample_frames:
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_target)
        ret, frame = cap.read()
        if not ret:
            continue
            
        try:
            results = DeepFace.analyze(
                img_path=frame, 
                actions=['emotion'], 
                enforce_detection=True, 
                detector_backend='ssd', 
                silent=True
            )
            
            if results:
                face = results[0]
                raw_scores = face.get('emotion', {})
                dominant = face.get('dominant_emotion')
                
                total = round(sum(raw_scores.values()), 2)
                if total > 0:
                    normalized_scores = {k: round(v / total, 4) for k, v in raw_scores.items()}
                    window_entries.append({
                        "dominant": dominant,
                        "scores": normalized_scores
                    })
        except Exception:
            pass # Skip frames where face detection fails cleanly
            
    cap.release()
    return window_entries

def format_window(window):
    """Replicates the format_window_for_classification logic from rina_node.py."""
    emotion_counts = {}
    emotion_averages = {}
    emotion_peaks = {}
    
    if not window:
        return {"counts": {}, "averages": {}, "peaks": {}}
        
    for entry in window:
        dominant = entry.get("dominant")
        if dominant:
            emotion_counts[dominant] = emotion_counts.get(dominant, 0) + 1
            
        scores = entry.get("scores", {})
        for emotion, score in scores.items():
            emotion_averages[emotion] = emotion_averages.get(emotion, 0) + score
            if emotion not in emotion_peaks or score > emotion_peaks[emotion]:
                emotion_peaks[emotion] = score
                
    return {
        "counts": emotion_counts,
        "averages": {emotion: score / len(window) for emotion, score in emotion_averages.items()},
        "peaks": emotion_peaks
    }

def calculate_pure_metrics(gt_list, pred_list):
    """Pure Python calculation of Precision, Recall, and F1-Score to avoid external dependencies."""
    # Find all unique classes present in either ground truth or predictions
    unique_classes = sorted(list(set(gt_list + pred_list)))
    
    report_lines = []
    header = f"{'Emotion':<15} {'Precision':<10} {'Recall':<10} {'F1-Score':<10} {'Support':<10}"
    report_lines.append(header)
    report_lines.append("-" * len(header))
    
    total_tp, total_fp, total_fn, total_support = 0, 0, 0, 0
    
    for cls in unique_classes:
        if cls == "error":
            continue
        tp = sum(1 for gt, pred in zip(gt_list, pred_list) if gt == cls and pred == cls)
        fp = sum(1 for gt, pred in zip(gt_list, pred_list) if gt != cls and pred == cls)
        fn = sum(1 for gt, pred in zip(gt_list, pred_list) if gt == cls and pred != cls)
        support = sum(1 for gt in gt_list if gt == cls)
        
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
        
        total_tp += tp
        total_fp += fp
        total_fn += fn
        total_support += support
        
        report_lines.append(f"{cls:<15} {precision:<10.2f} {recall:<10.2f} {f1:<10.2f} {support:<10}")
        
    report_lines.append("-" * len(header))
    
    # Calculate global Accuracy
    correct_predictions = sum(1 for gt, pred in zip(gt_list, pred_list) if gt == pred)
    accuracy = correct_predictions / len(gt_list) if len(gt_list) > 0 else 0.0
    report_lines.append(f"{'Accuracy':<15} {'':<10} {'':<10} {accuracy:<10.2f} {len(gt_list):<10}")
    
    return "\n".join(report_lines)

def run_evaluation_suite(dataset_dir, csv_filename):
    csv_path = os.path.join(dataset_dir, csv_filename)
    
    if not os.path.exists(csv_path):
        print(f"ERROR: Cannot find {csv_path}. Please check your dataset directory.")
        return
        
    df = pd.read_csv(csv_path)
    df_samples = df.head(100)
    print(f"Loaded {len(df_samples)} samples from {csv_path}.")
    
    for model_name in MODELS_TO_TEST:
        print(f"\n" + "="*60)
        print(f"STARTING EVALUATION RUN FOR MODEL: {model_name}")
        print("="*60)
        
        bot = EmotionalBot(model_name=model_name)
        results_log = []
        
        gt_accumulator = []
        pred_accumulator = []
        
        for index, row in tqdm(df_samples.iterrows(), total=len(df_samples), desc=f"Processing [{model_name}]"):
            dialogue_id = row['Dialogue_ID']
            utterance_id = row['Utterance_ID']
            ground_truth = str(row['Emotion']).lower().strip()
            transcript = row['Utterance']
            
            filename = f"dia{dialogue_id}_utt{utterance_id}.mp4"
            file_path = os.path.join(dataset_dir, "train_splits", filename)
            
            raw_window = process_video_face_data(file_path)
            formatted_face_data = format_window(raw_window)
            df_dominant = max(formatted_face_data["counts"], key=formatted_face_data["counts"].get) if formatted_face_data["counts"] else "None"
            
            bot.reset()
            
            try:
                llm_response = bot.chat(transcript, formatted_face_data)
                parsed_commands = extract_llm_commands(llm_response.robot_response)
                
                predicted_emotion = llm_response.classified_emotion.strip().lower()
                gt_accumulator.append(ground_truth)
                pred_accumulator.append(predicted_emotion)
                
                results_log.append({
                    "Filename": filename,
                    "Dialogue_ID": dialogue_id,
                    "Utterance_ID": utterance_id,
                    "Ground_Truth_Emotion": ground_truth,
                    "Transcript": transcript,
                    "DeepFace_Dominant": df_dominant,
                    "LLM_Classified_Emotion": predicted_emotion,
                    "LLM_Mismatch_Detected": llm_response.mismatch_detected,
                    "LLM_Mismatch_Reason": llm_response.mismatch_reason,
                    "LLM_Selected_Tone": parsed_commands["tone"],
                    "LLM_Selected_Expression": parsed_commands["expression"],
                    "LLM_Selected_Gesture": parsed_commands["gesture"],
                    "Raw_Robot_Reply": llm_response.robot_response
                })
            except Exception as e:
                gt_accumulator.append(ground_truth)
                pred_accumulator.append("error")
                results_log.append({
                    "Filename": filename,
                    "Dialogue_ID": dialogue_id,
                    "Utterance_ID": utterance_id,
                    "Ground_Truth_Emotion": ground_truth,
                    "Transcript": transcript,
                    "DeepFace_Dominant": df_dominant,
                    "LLM_Classified_Emotion": "error",
                    "LLM_Mismatch_Detected": "TIMEOUT/ERROR",
                    "LLM_Mismatch_Reason": str(e),
                    "LLM_Selected_Tone": "None",
                    "LLM_Selected_Expression": "None",
                    "LLM_Selected_Gesture": "None",
                    "Raw_Robot_Reply": "ERROR"
                })
                
        clean_model_name = model_name.replace(":", "_").replace(".", "_")
        output_csv_filename = f"results_meld_{clean_model_name}.csv"
        output_summary_filename = f"summary_meld_{clean_model_name}.txt"
        
        df_results = pd.DataFrame(results_log)
        df_results.to_csv(output_csv_filename, index=False)
        print(f"Logged raw text results to -> {output_csv_filename}")
        
        # Calculate final precision, recall, and f1 statistics automatically in pure Python
        try:
            report = calculate_pure_metrics(gt_accumulator, pred_accumulator)
            
            with open(output_summary_filename, "w") as f:
                f.write(f"=== MELD EVALUATION SUMMARY FOR {model_name} ===\n\n")
                f.write(report)
                
            print(f"Saved custom F1-Report -> {output_summary_filename}")
            print("\nPreview of performance metrics:\n", report)
        except Exception as stats_err:
            print(f"Could not calculate metrics summary: {stats_err}")

if __name__ == "__main__":
    DATASET_DIRECTORY = "MELD_dataset"
    CSV_FILENAME = "train_sent_emo.csv"
    run_evaluation_suite(DATASET_DIRECTORY, CSV_FILENAME)
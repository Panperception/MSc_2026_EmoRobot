"""
Test 2: Instruction Following
Checks whether models use gestures/expressions/tones correctly:
- Valid command names only
- Emotionally appropriate commands
- Not overusing commands (max 1 gesture + 1 expression per response)
- No commands used for clearly neutral inputs

Each test case has an expected emotional context (positive/negative/neutral).
Score is reported per model.
"""

import re
from eval_config import MODELS, VALID_TONES, VALID_GESTURES, VALID_EXPRESSIONS
from eval_config import NEUTRAL_FACE, HAPPY_FACE, SAD_FACE, run_single_chat

POSITIVE_GESTURES = {"happy", "clapping", "hi", "kiss", "send_kiss"}
POSITIVE_EXPRESSIONS = {"happy", "happy_blinking", "kiss", "one_eye_win", "shy"}
POSITIVE_TONES = {"upbeat", "enthusiastic"}

NEGATIVE_GESTURES = {"sad", "angry", "peekaboo", "bored"}
NEGATIVE_EXPRESSIONS = {"sad", "angry", "cry", "disgusted", "confused"}
NEGATIVE_TONES = {"gentle", "calm"}

TEST_CASES = [
    # (transcript, face, expected_sentiment)
    ("I just got a promotion at work! I'm so happy!", HAPPY_FACE,   "positive"),
    ("I had the best day ever today!",                HAPPY_FACE,   "positive"),
    ("We won the competition!",                       HAPPY_FACE,   "positive"),
    ("I feel so proud of what I achieved.",           HAPPY_FACE,   "positive"),
    ("I've been feeling really low lately.",          SAD_FACE,     "negative"),
    ("I lost my job today. I don't know what to do.",SAD_FACE,     "negative"),
    ("I'm really struggling to cope.",                SAD_FACE,     "negative"),
    ("Everything feels hopeless right now.",          SAD_FACE,     "negative"),
    ("What is your name?",                            NEUTRAL_FACE, "neutral"),
    ("Tell me something interesting.",                NEUTRAL_FACE, "neutral"),
    ("What time is it?",                              NEUTRAL_FACE, "neutral"),
    ("How does weather work?",                        NEUTRAL_FACE, "neutral"),
]

def extract_commands(text):
    tones = re.findall(r'\{tone:(\w+)\}', text)
    gestures = re.findall(r'\{gesture:(\w+)\}', text)
    expressions = re.findall(r'\{expression:(\w+)\}', text)
    return tones, gestures, expressions

def score_response(response_line, expected_sentiment):
    tones, gestures, expressions = extract_commands(response_line)
    issues = []
    score = 5  # start at 5, deduct for issues

    # Check valid names
    for t in tones:
        if t not in VALID_TONES:
            issues.append(f"invalid tone '{t}'")
            score -= 1
    for g in gestures:
        if g not in VALID_GESTURES:
            issues.append(f"invalid gesture '{g}'")
            score -= 1
    for e in expressions:
        if e not in VALID_EXPRESSIONS:
            issues.append(f"invalid expression '{e}'")
            score -= 1

    # Check overuse
    if len(gestures) > 1:
        issues.append("too many gestures")
        score -= 1
    if len(expressions) > 1:
        issues.append("too many expressions")
        score -= 1

    # Check emotional appropriateness
    if expected_sentiment == "positive":
        for g in gestures:
            if g in NEGATIVE_GESTURES:
                issues.append(f"negative gesture '{g}' for positive context")
                score -= 1
        for e in expressions:
            if e in NEGATIVE_EXPRESSIONS:
                issues.append(f"negative expression '{e}' for positive context")
                score -= 1

    elif expected_sentiment == "negative":
        for g in gestures:
            if g in POSITIVE_GESTURES:
                issues.append(f"positive gesture '{g}' for negative context")
                score -= 1
        for e in expressions:
            if e in POSITIVE_EXPRESSIONS:
                issues.append(f"positive expression '{e}' for negative context")
                score -= 1

    elif expected_sentiment == "neutral":
        if gestures or expressions:
            issues.append("used commands for neutral input (unnecessary)")
            score -= 1

    return max(0, score), issues

def run():
    print("=" * 60)
    print("TEST 2: INSTRUCTION FOLLOWING")
    print("=" * 60)

    for model in MODELS:
        print(f"\nModel: {model}")
        total_score = 0
        max_score = 0

        for transcript, face, sentiment in TEST_CASES:
            try:
                result = run_single_chat(model, transcript, face)
                if not result.format_ok:
                    print(f"  [SKIP - bad format] {transcript[:50]}")
                    continue

                score, issues = score_response(result.response_line, sentiment)
                total_score += score
                max_score += 5
                status = "OK" if score == 5 else f"score={score}/5"
                print(f"  [{status}] ({sentiment}) {transcript[:45]}")
                if issues:
                    for iss in issues:
                        print(f"         ! {iss}")
            except Exception as e:
                print(f"  [ERROR] {transcript[:50]} → {e}")

        if max_score > 0:
            pct = 100 * total_score // max_score
            print(f"\n  Total score: {total_score}/{max_score} ({pct}%)")
        else:
            print("  No scoreable responses.")

    print("\n" + "=" * 60)
    print("DONE")
    print("=" * 60)

if __name__ == "__main__":
    run()

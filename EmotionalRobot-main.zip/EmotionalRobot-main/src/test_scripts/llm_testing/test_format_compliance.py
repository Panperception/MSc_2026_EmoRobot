"""
Test 1: Format Compliance
Checks whether each model reliably outputs the required MISMATCH: / RESPONSE: format.
Also checks that the response text is speakable:
  - No emojis or emoticons
  - No special/non-ASCII characters
  - No markdown symbols (**, __, ##, etc.)
Runs 20 inputs per model and counts pass/failures with detailed reasons.
"""

import re
from eval_config import MODELS, NEUTRAL_FACE, run_single_chat

TEST_INPUTS = [
    "Hello, how are you?",
    "I just got a promotion at work!",
    "I've been feeling really down lately.",
    "What is your name?",
    "Can you tell me a joke?",
    "I'm so stressed about my exams.",
    "I had a great day today!",
    "I don't really want to talk right now.",
    "What do you think about the weather?",
    "I'm feeling a bit lonely.",
    "That was really funny, thank you!",
    "I'm nervous about meeting new people.",
    "Do you have any hobbies?",
    "I feel like nobody understands me.",
    "I just finished a really good book.",
    "Can you help me feel better?",
    "I'm so excited about my holiday!",
    "Everything feels overwhelming right now.",
    "Tell me something interesting.",
    "I think I need some rest.",
]

# Markdown patterns that would appear in spoken text
MARKDOWN_PATTERN = re.compile(r'(\*{1,2}|_{1,2}|#{1,2}|`+|~~)')

# Emoticons: common text-based ones
EMOTICON_PATTERN = re.compile(
    r'(:\)|:\(|:D|:P|;\)|:o|>_<|<3|XD|:\'[(\)]|8\)|-_-|\^_\^)'
)

def contains_emoji(text):
    """Check for Unicode emoji characters."""
    for char in text:
        cp = ord(char)
        if (
            0x1F600 <= cp <= 0x1F64F or  # emoticons
            0x1F300 <= cp <= 0x1F5FF or  # misc symbols/pictographs
            0x1F680 <= cp <= 0x1F6FF or  # transport/map
            0x1F700 <= cp <= 0x1F77F or  # alchemical
            0x1F780 <= cp <= 0x1F7FF or  # geometric
            0x1F800 <= cp <= 0x1F8FF or  # supplemental arrows
            0x1F900 <= cp <= 0x1F9FF or  # supplemental symbols
            0x1FA00 <= cp <= 0x1FA6F or  # chess symbols
            0x1FA70 <= cp <= 0x1FAFF or  # symbols and pictographs extended
            0x2600  <= cp <= 0x26FF  or  # misc symbols
            0x2700  <= cp <= 0x27BF  or  # dingbats
            0xFE00  <= cp <= 0xFE0F  or  # variation selectors
            0x1F1E0 <= cp <= 0x1F1FF     # flags
        ):
            return True
    return False

def contains_non_speakable(text):
    """
    Strip out known inline commands {tone:x} {gesture:x} {expression:x}
    then check remaining text for non-speakable content.
    Returns a list of issue strings, empty if clean.
    """
    # Remove inline commands before checking
    clean = re.sub(r'\{[^}]+\}', '', text)

    issues = []

    if contains_emoji(clean):
        issues.append("contains emoji")

    if EMOTICON_PATTERN.search(clean):
        issues.append("contains emoticon")

    if MARKDOWN_PATTERN.search(clean):
        issues.append("contains markdown symbols")

    # Non-ASCII characters (excluding smart quotes and common punctuation)
    non_ascii = [ch for ch in clean if ord(ch) > 127 and ord(ch) not in (
        0x2018, 0x2019, 0x201C, 0x201D,  # smart quotes
        0x2014, 0x2013,                   # em/en dash
        0x2026,                           # ellipsis
        0x00E9, 0x00E8, 0x00EA,           # accented e (common in English text)
    )]
    if non_ascii:
        issues.append(f"non-ASCII chars: {''.join(set(non_ascii))!r}")

    return issues


def run():
    print("=" * 60)
    print("TEST 1: FORMAT COMPLIANCE")
    print("=" * 60)

    for model in MODELS:
        passed = 0
        failed = 0
        failures = []

        print(f"\nModel: {model}")
        for i, transcript in enumerate(TEST_INPUTS):
            try:
                result = run_single_chat(model, transcript, NEUTRAL_FACE)

                issues = []

                if not result.format_ok:
                    if not result.has_mismatch_line:
                        issues.append("missing MISMATCH line")
                    if not result.has_response_line:
                        issues.append("missing RESPONSE line")

                if result.has_response_line:
                    speakable_issues = contains_non_speakable(result.response_line)
                    issues.extend(speakable_issues)

                if issues:
                    failed += 1
                    failures.append({"input": transcript, "issues": issues, "raw": result.raw[:150]})
                    print(f"  [{i+1:02d}] FAIL — {transcript[:45]} | {', '.join(issues)}")
                else:
                    passed += 1
                    print(f"  [{i+1:02d}] PASS — {transcript[:50]}")

            except Exception as e:
                failed += 1
                failures.append({"input": transcript, "error": str(e)})
                print(f"  [{i+1:02d}] ERROR — {e}")

        total = passed + failed
        print(f"\n  Result: {passed}/{total} passed ({100*passed//total}%)")

        if failures:
            print("  Failures:")
            for f in failures:
                if "error" in f:
                    print(f"    - '{f['input']}' → ERROR: {f['error']}")
                else:
                    print(f"    - '{f['input']}' → {', '.join(f['issues'])}")
                    print(f"      Raw: {f['raw']!r}")

    print("\n" + "=" * 60)
    print("DONE")
    print("=" * 60)

if __name__ == "__main__":
    run()
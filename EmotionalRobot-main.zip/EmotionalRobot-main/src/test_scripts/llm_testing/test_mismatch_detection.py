"""
Test 3: Mismatch Detection Accuracy
Feeds the model cases where face and transcript agree (no mismatch expected)
and cases where they conflict (mismatch expected).
Reports true positives, false positives, true negatives, false negatives.
"""

from eval_config import MODELS, HAPPY_FACE, SAD_FACE, NEUTRAL_FACE, run_single_chat

# (transcript, face, expect_mismatch, description)
TEST_CASES = [
    # Clear matches — expect NO mismatch
    ("I'm so happy today, everything is going great!",   HAPPY_FACE,   False, "happy transcript + happy face"),
    ("This is the best news I've heard all week!",        HAPPY_FACE,   False, "positive transcript + happy face"),
    ("I feel so sad and down right now.",                  SAD_FACE,     False, "sad transcript + sad face"),
    ("I've been crying all morning.",                      SAD_FACE,     False, "sad transcript + sad face"),
    ("What is your name?",                                 NEUTRAL_FACE, False, "neutral transcript + neutral face"),
    ("Tell me something interesting.",                     NEUTRAL_FACE, False, "neutral transcript + neutral face"),

    # Clear mismatches — expect YES mismatch
    ("I'm doing absolutely great, never been better!",    SAD_FACE,     True,  "happy transcript + sad face"),
    ("Everything is wonderful and I'm so excited!",       SAD_FACE,     True,  "excited transcript + sad face"),
    ("I feel terrible, I can't stop crying.",              HAPPY_FACE,   True,  "sad transcript + happy face"),
    ("I'm devastated, I don't know what to do.",           HAPPY_FACE,   True,  "distressed transcript + happy face"),
    ("I feel completely fine, nothing is wrong.",          SAD_FACE,     True,  "dismissive transcript + sad face"),
    ("I'm totally calm and relaxed.",                      SAD_FACE,     True,  "calm transcript + sad face"),
]

def run():
    print("=" * 60)
    print("TEST 3: MISMATCH DETECTION ACCURACY")
    print("=" * 60)

    for model in MODELS:
        print(f"\nModel: {model}")
        tp = fp = tn = fn = 0

        for transcript, face, expect_mismatch, desc in TEST_CASES:
            try:
                result = run_single_chat(model, transcript, face)
                if not result.format_ok:
                    print(f"  [SKIP - bad format] {desc}")
                    continue

                detected = result.mismatch_detected
                expected = expect_mismatch

                if detected and expected:
                    outcome = "TP"; tp += 1
                elif detected and not expected:
                    outcome = "FP"; fp += 1
                elif not detected and not expected:
                    outcome = "TN"; tn += 1
                else:
                    outcome = "FN"; fn += 1

                print(f"  [{outcome}] {desc}")
                if detected:
                    print(f"       Reason: {result.mismatch_line}")

            except Exception as e:
                print(f"  [ERROR] {desc} → {e}")

        total = tp + fp + tn + fn
        if total > 0:
            accuracy = 100 * (tp + tn) // total
            precision = (100 * tp // (tp + fp)) if (tp + fp) > 0 else 0
            recall    = (100 * tp // (tp + fn)) if (tp + fn) > 0 else 0
            print(f"\n  TP={tp}  FP={fp}  TN={tn}  FN={fn}")
            print(f"  Accuracy:  {accuracy}%")
            print(f"  Precision: {precision}%  (of flagged mismatches, how many were real)")
            print(f"  Recall:    {recall}%    (of real mismatches, how many were caught)")

    print("\n" + "=" * 60)
    print("DONE")
    print("=" * 60)

if __name__ == "__main__":
    run()

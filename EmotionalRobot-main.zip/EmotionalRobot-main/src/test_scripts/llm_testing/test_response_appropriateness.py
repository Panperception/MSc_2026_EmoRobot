"""
Test 6: Response Appropriateness
This test cannot be fully automated — it requires a human to rate
whether each response feels natural and empathetic for a social robot.

The script runs each model on a set of emotionally varied inputs,
prints the responses clearly, and prompts you to enter a score (1-5).
Scores are saved to response_appropriateness_results.txt.

Rating guide:
  5 - Excellent: natural, empathetic, fits the situation perfectly
  4 - Good: appropriate, minor issues with tone or wording
  3 - Acceptable: response is relevant but feels a bit off or robotic
  2 - Poor: inappropriate tone, irrelevant content, or awkward phrasing
  1 - Very poor: confusing, unhelpful, or completely wrong for context
"""

from eval_config import MODELS, NEUTRAL_FACE, HAPPY_FACE, SAD_FACE, run_single_chat

TEST_CASES = [
    ("Hello, how are you today?",                   NEUTRAL_FACE, "Casual greeting"),
    ("I just found out I passed my exams!",          HAPPY_FACE,   "Positive news"),
    ("I lost someone close to me recently.",         SAD_FACE,     "Grief/loss"),
    ("I'm feeling really anxious about tomorrow.",   SAD_FACE,     "Anxiety"),
    ("Can you cheer me up?",                         SAD_FACE,     "Request for comfort"),
    ("I'm bored, what should I talk to you about?", NEUTRAL_FACE, "Open-ended boredom"),
    ("I feel so proud of myself today!",             HAPPY_FACE,   "Self-pride"),
    ("Nobody seems to care about me.",               SAD_FACE,     "Loneliness"),
]

RESULTS_FILE = "response_appropriateness_results.txt"

def run():
    print("=" * 60)
    print("TEST 6: RESPONSE APPROPRIATENESS (Human-rated)")
    print("=" * 60)
    print("You will be shown each model's response and asked to rate it 1-5.")
    print("Press Enter to skip a rating (it won't be recorded).")
    print()

    all_results = []

    for model in MODELS:
        print(f"\n{'='*60}")
        print(f"MODEL: {model}")
        print(f"{'='*60}")
        model_scores = []

        for transcript, face, context in TEST_CASES:
            print(f"\nContext:    {context}")
            print(f"Transcript: {transcript}")

            try:
                result = run_single_chat(model, transcript, face)

                if not result.format_ok:
                    print("  [Bad format - skipping rating]")
                    continue

                print(f"Response:   {result.response_line}")
                print(f"Mismatch:   {result.mismatch_line}")

                while True:
                    raw = input("  Rate 1-5 (or Enter to skip): ").strip()
                    if raw == "":
                        break
                    if raw in {"1", "2", "3", "4", "5"}:
                        score = int(raw)
                        model_scores.append(score)
                        all_results.append({
                            "model": model,
                            "context": context,
                            "transcript": transcript,
                            "response": result.response_line,
                            "score": score
                        })
                        break
                    print("  Please enter a number between 1 and 5.")

            except Exception as e:
                print(f"  [ERROR] {e}")

        if model_scores:
            avg = sum(model_scores) / len(model_scores)
            print(f"\n  Average score for {model}: {avg:.2f}/5 ({len(model_scores)} rated)")

    # Save results
    with open(RESULTS_FILE, "w") as f:
        f.write("RESPONSE APPROPRIATENESS RESULTS\n")
        f.write("=" * 60 + "\n\n")

        # Summary per model
        models_seen = {}
        for r in all_results:
            models_seen.setdefault(r["model"], []).append(r["score"])

        f.write("SUMMARY\n")
        for m, scores in models_seen.items():
            avg = sum(scores) / len(scores)
            f.write(f"  {m}: {avg:.2f}/5 (n={len(scores)})\n")

        f.write("\nDETAILED RESULTS\n")
        for r in all_results:
            f.write(f"\nModel:    {r['model']}\n")
            f.write(f"Context:  {r['context']}\n")
            f.write(f"Input:    {r['transcript']}\n")
            f.write(f"Response: {r['response']}\n")
            f.write(f"Score:    {r['score']}/5\n")

    print(f"\n\nResults saved to {RESULTS_FILE}")
    print("=" * 60)
    print("DONE")
    print("=" * 60)

if __name__ == "__main__":
    run()

import ollama
from pydantic import BaseModel

MODELS = [
    "gemma3:4b",
    "llama3.2:3b",
    "qwen2.5:3b",
    "granite3.2:2b",
    "smollm2:latest",
    "mistral:7b",
    "phi4-mini:latest",
]

COMPACT_PROMPT = f"""
You are QT, a friendly and empathetic social robot. Have natural, spoken conversations with users. You can include inline commands to control gestures, facial expressions, and tone. Use the exact syntax:

{{tone:NAME}}       - sets speaking tone (applies to text after it)
{{gesture:NAME}}    - plays a physical gesture
{{expression:NAME}} - shows a facial expression

## Tones
gentle, calm, normal, upbeat, enthusiastic

## Gestures
Positive: happy, clapping, hi, bye, kiss, send_kiss, show_QT
Negative: sad, angry, peekaboo, bored
Neutral: neutral, point_front, touch_head, stretching, yawn, drink, breathing_exercise

## Expressions
Positive: happy, happy_blinking, kiss, one_eye_win, shy
Negative: sad, angry, cry, disgusted, confused, suprise, sceam
Neutral: blowing_rasberry, calming_down, yawn, breathing_exercise
Note: "suprise" and "sceam" are spelled exactly as shown.

## Command rules
- Most short replies need no gesture or expression. Only use them when they add meaning.
- Gestures and expressions must match emotionally when used together.
- Place commands at the natural moment in the response, not all at the start.
- After a strong emotional moment, return to a calmer state in the next response.
- Use at most one gesture and one expression per response.

## Speech rules
- This text will be spoken aloud. Write naturally as you would speak.
- Do not use emojis, emoticons, or special characters such as asterisks, percent signs, ampersands, or bullet symbols.
- Avoid markdown formatting. Write in plain conversational sentences.

## Output format
Always respond using exactly these two lines:
MISMATCH: yes/<reason> or no
RESPONSE: <your reply with any inline commands>

## Examples
User says they just got a promotion:
MISMATCH: no
RESPONSE: {{tone:enthusiastic}}{{expression:happy}}That is wonderful news! {{gesture:clapping}} Congratulations, you must be so proud of yourself.

User says they are feeling down:
MISMATCH: no
RESPONSE: {{tone:gentle}}{{expression:sad}}I am really sorry to hear that. {{gesture:sad}} Do you want to talk about what has been going on?
"""

VALID_TONES = {"gentle", "calm", "normal", "upbeat", "enthusiastic"}
VALID_GESTURES = {
    "happy", "clapping", "hi", "bye", "kiss", "send_kiss", "show_QT",
    "sad", "angry", "peekaboo", "bored",
    "neutral", "point_front", "touch_head", "stretching", "yawn",
    "drink", "breathing_exercise"
}
VALID_EXPRESSIONS = {
    "happy", "happy_blinking", "kiss", "one_eye_win", "shy",
    "sad", "angry", "cry", "disgusted", "confused", "suprise", "sceam",
    "blowing_rasberry", "calming_down", "yawn", "breathing_exercise"
}


class ParsedResponse:
    def __init__(self, raw: str):
        self.raw = raw
        self.mismatch_line = ""
        self.response_line = ""
        self.has_mismatch_line = False
        self.has_response_line = False
        self.mismatch_detected = False

        for line in raw.strip().splitlines():
            if line.startswith("MISMATCH:"):
                self.has_mismatch_line = True
                self.mismatch_line = line[len("MISMATCH:"):].strip()
                self.mismatch_detected = self.mismatch_line.lower().startswith("yes")
            elif line.startswith("RESPONSE:"):
                self.has_response_line = True
                self.response_line = line[len("RESPONSE:"):].strip()

    @property
    def format_ok(self):
        return self.has_mismatch_line and self.has_response_line

    @property
    def word_count(self):
        import re
        clean = re.sub(r'\{[^}]+\}', '', self.response_line)
        return len(clean.split())


def run_single_chat(model: str, transcript: str, deepface_data: dict) -> ParsedResponse:
    history = [{"role": "system", "content": COMPACT_PROMPT}]
    user_message = f"TRANSCRIPT: {transcript}\nFACE: {deepface_data}"
    history.append({"role": "user", "content": user_message})
    response = ollama.chat(model=model, messages=history)
    return ParsedResponse(response["message"]["content"])


NEUTRAL_FACE = {
    'counts': {'neutral': 24},
    'averages': {'angry': 0.02, 'disgust': 0.0, 'fear': 0.001, 'happy': 0.002,
                 'sad': 0.027, 'surprise': 0.0, 'neutral': 0.944},
    'peaks': {'angry': 0.13, 'disgust': 0.0, 'fear': 0.003, 'happy': 0.01,
              'sad': 0.095, 'surprise': 0.0, 'neutral': 0.997}
}

HAPPY_FACE = {
    'counts': {'happy': 20, 'neutral': 4},
    'averages': {'angry': 0.01, 'disgust': 0.0, 'fear': 0.0, 'happy': 0.82,
                 'sad': 0.01, 'surprise': 0.02, 'neutral': 0.14},
    'peaks': {'angry': 0.02, 'disgust': 0.0, 'fear': 0.0, 'happy': 0.98,
              'sad': 0.02, 'surprise': 0.05, 'neutral': 0.30}
}

SAD_FACE = {
    'counts': {'sad': 18, 'neutral': 6},
    'averages': {'angry': 0.03, 'disgust': 0.0, 'fear': 0.01, 'happy': 0.01,
                 'sad': 0.75, 'surprise': 0.0, 'neutral': 0.20},
    'peaks': {'angry': 0.05, 'disgust': 0.0, 'fear': 0.02, 'happy': 0.02,
              'sad': 0.94, 'surprise': 0.0, 'neutral': 0.35}
}

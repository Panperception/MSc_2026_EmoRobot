"""
Test 5: Robustness to Noisy Input
Tests how well models handle imperfect speech-to-text transcripts:
- Incomplete sentences
- Filler words and hesitation
- Garbled/misspelled words
- Partial utterances
- Mixed garbling + emotion

Each noisy input has a clean equivalent. We check whether the model
still produces a valid, sensible response rather than failing or
producing a confused reply.
Scoring is automatic (format compliance + non-empty response),
with the raw response printed for manual review.
"""

from eval_config import MODELS, NEUTRAL_FACE, SAD_FACE, HAPPY_FACE, run_single_chat

# (noisy_transcript, face, description, clean_equivalent)
TEST_CASES = [
    ("uh… I just… yeah I dunno",
     NEUTRAL_FACE, "hesitation/trailing off", "I don't know what to say"),

    ("I feel kind of… I don't know… just not great I guess",
     SAD_FACE, "incomplete + uncertain", "I'm feeling a bit down"),

    ("so um I was thinking maybe we could uh talk about",
     NEUTRAL_FACE, "filler words, no ending", "Can we talk?"),

    ("im fne evreything is grt",
     HAPPY_FACE, "misspelled words", "I'm fine everything is great"),

    ("I jus got prmoted at wrk!!",
     HAPPY_FACE, "garbled positive news", "I just got promoted at work"),

    ("i… i cant",
     SAD_FACE, "very short incomplete", "I can't cope"),

    ("yeah no I mean it's like whatever you know",
     NEUTRAL_FACE, "vague/filler heavy", "It doesn't really matter"),

    ("the thing is um I just feel like nobody uh listens to me you know what I mean",
     SAD_FACE, "filler + emotional content", "Nobody listens to me"),

    ("I dunno maybe Im overreacting but like it really bothered me",
     SAD_FACE, "self-doubt + emotion", "Something bothered me a lot"),

    ("hahaha omg that was SO funny I cant even",
     HAPPY_FACE, "informal/internet speak", "That was really funny"),
]

def run():
    print("=" * 60)
    print("TEST 5: ROBUSTNESS TO NOISY INPUT")
    print("=" * 60)

    for model in MODELS:
        print(f"\nModel: {model}")
        passed = 0
        total = 0

        for noisy, face, desc, clean in TEST_CASES:
            try:
                result = run_single_chat(model, noisy, face)
                total += 1

                format_ok = result.format_ok
                has_content = len(result.response_line.strip()) > 5

                ok = format_ok and has_content
                if ok:
                    passed += 1

                status = "OK" if ok else "FAIL"
                print(f"  [{status}] {desc}")
                print(f"         Noisy:    {noisy[:60]}")
                print(f"         Response: {result.response_line[:80]}")
                if not format_ok:
                    print(f"         ! Bad format")
                if not has_content:
                    print(f"         ! Empty or near-empty response")

            except Exception as e:
                total += 1
                print(f"  [ERROR] {desc} → {e}")

        if total > 0:
            print(f"\n  Passed: {passed}/{total} ({100*passed//total}%)")

    print("\n" + "=" * 60)
    print("DONE")
    print("=" * 60)

if __name__ == "__main__":
    run()

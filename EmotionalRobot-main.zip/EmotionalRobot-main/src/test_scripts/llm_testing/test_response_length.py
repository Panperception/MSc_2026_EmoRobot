"""
Test 4: Response Length Consistency
Measures word count of each response (excluding inline commands).
Reports mean, min, max, and standard deviation per model.
Flags responses that are too short (<5 words) or too long (>50 words).
"""

import re
import statistics
from eval_config import MODELS, NEUTRAL_FACE, HAPPY_FACE, SAD_FACE, run_single_chat

TEST_CASES = [
    ("Hello, how are you?",                           NEUTRAL_FACE),
    ("What is your name?",                            NEUTRAL_FACE),
    ("Tell me something interesting.",                NEUTRAL_FACE),
    ("I just got a promotion!",                       HAPPY_FACE),
    ("I had a great day today.",                      HAPPY_FACE),
    ("We won the competition!",                       HAPPY_FACE),
    ("I've been feeling really down lately.",         SAD_FACE),
    ("I lost my job today.",                          SAD_FACE),
    ("I'm struggling to cope right now.",             SAD_FACE),
    ("Can you tell me a joke?",                       NEUTRAL_FACE),
    ("What do you think about the weather?",          NEUTRAL_FACE),
    ("I'm so excited about my holiday!",              HAPPY_FACE),
    ("Everything feels overwhelming right now.",      SAD_FACE),
    ("Do you have any hobbies?",                      NEUTRAL_FACE),
    ("I feel like nobody understands me.",            SAD_FACE),
]

TOO_SHORT = 5
TOO_LONG = 50

def clean_word_count(text):
    clean = re.sub(r'\{[^}]+\}', '', text)
    return len(clean.split())

def run():
    print("=" * 60)
    print("TEST 4: RESPONSE LENGTH CONSISTENCY")
    print("=" * 60)

    for model in MODELS:
        print(f"\nModel: {model}")
        word_counts = []
        flagged = []

        for transcript, face in TEST_CASES:
            try:
                result = run_single_chat(model, transcript, face)
                if not result.format_ok:
                    print(f"  [SKIP - bad format] {transcript[:50]}")
                    continue

                wc = clean_word_count(result.response_line)
                word_counts.append(wc)

                flag = ""
                if wc < TOO_SHORT:
                    flag = "TOO SHORT"
                    flagged.append((transcript, wc, flag))
                elif wc > TOO_LONG:
                    flag = "TOO LONG"
                    flagged.append((transcript, wc, flag))

                print(f"  [{wc:3d} words] {'['+flag+']' if flag else ''} {transcript[:50]}")

            except Exception as e:
                print(f"  [ERROR] {transcript[:50]} → {e}")

        if word_counts:
            mean = sum(word_counts) / len(word_counts)
            stdev = statistics.stdev(word_counts) if len(word_counts) > 1 else 0
            print(f"\n  Mean:   {mean:.1f} words")
            print(f"  Min:    {min(word_counts)} words")
            print(f"  Max:    {max(word_counts)} words")
            print(f"  StdDev: {stdev:.1f} words")
            print(f"  Flagged: {len(flagged)}/{len(word_counts)} responses")

    print("\n" + "=" * 60)
    print("DONE")
    print("=" * 60)

if __name__ == "__main__":
    run()

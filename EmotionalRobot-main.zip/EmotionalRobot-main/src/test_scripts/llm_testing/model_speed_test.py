import ollama
from pydantic import BaseModel
import time


class EmotionResponse(BaseModel):
    mismatch_detected: bool
    mismatch_reason: str
    robot_response: str

TONE_MAP = {
    "gentle":       "\\vct=97\\\\rspd=82\\\\vol=65\\",
    "calm":         "\\vct=98\\\\rspd=90\\\\vol=70\\",
    "normal":       "\\vct=100\\\\rspd=100\\\\vol=80\\",
    "upbeat":       "\\vct=103\\\\rspd=108\\\\vol=85\\",
    "enthusiastic": "\\vct=107\\\\rspd=118\\\\vol=90\\",
}

COMPACT_PROMPT = f"""
You are QT, a friendly and empathetic social robot. Your job is to have 
natural conversations with users and respond helpfully to what they say.

You can include inline commands to control the robot's gestures, facial 
expressions, and tone of voice. Use the exact syntax shown:

  {{tone:NAME}}       - sets speaking tone (applies to text after it)
  {{gesture:NAME}}    - plays a physical gesture
  {{expression:NAME}} - shows a facial expression

## Tones
gentle, calm, normal, upbeat, enthusiastic

## Gestures (grouped by feeling)

Positive / warm:
  happy          - throws arms in the air
  clapping       - claps hands
  hi             - waves hello
  bye            - waves goodbye
  kiss           - blows a small kiss
  send_kiss      - bigger kiss gesture with extended arm
  show_QT        - points to itself

Negative / low:
  sad            - head down, shakes head
  angry          - both hands on hips
  peekaboo       - head in hands (use for disappointment or shame)
  bored          - looks around bored

Neutral / functional:
  neutral             - returns body to rest position
  point_front         - points forward
  touch_head          - hands on head
  stretching          - performs stretches
  yawn                - yawns
  drink               - drinking motion
  breathing_exercise  - hands together moving up and down (use when 
                       guiding user through a calming exercise)

## Expressions
Positive: happy, happy_blinking, kiss, one_eye_win, shy
Negative: sad, angry, cry, disgusted, confused, suprise, sceam
Neutral / playful: blowing_rasberry, calming_down, yawn, breathing_exercise

Note: "suprise" and "sceam" are spelled as shown — use those exact strings.

## When to use commands

- Most short conversational replies need NO gesture or expression. 
  Only include them when they meaningfully add to the response.
- If you use a gesture and expression together, they should match 
  emotionally (e.g. {{gesture:happy}} with {{expression:happy}}, 
  {{gesture:angry}} with {{expression:angry}}).
- Place commands at the natural moment in the response, not all at 
  the start. The gesture/expression should land alongside the words 
  that relate to it.
- After a strongly emotional moment has passed, return to a calmer 
  state in the next response (e.g. {{expression:happy_blinking}} or 
  no expression at all) rather than leaving the robot stuck on an 
  intense face.
- Aim for at most one gesture and one expression per response.

## Output format
Always respond using exactly these two lines:
MISMATCH: yes/<reason> or no
RESPONSE: <your reply with any inline commands>

## Example

User says they just got a promotion. A good response:

  {{tone:enthusiastic}}{{expression:happy}}That's wonderful news! 
  {{gesture:clapping}} Congratulations, you must be so proud.

User says they're feeling down. A good response:

  {{tone:gentle}}{{expression:sad}}I'm really sorry to hear that. 
  {{gesture:sad}} Do you want to talk about what's been going on?
"""

class EmotionalBot:
    def __init__(self):
        self.model = "phi4-mini:latest"    #llama3.2:3b
        self.conversation_history = [
            {"role": "system", "content": COMPACT_PROMPT}
        ]
    
    def chat(self, transcript, deepface_data):
        #user message
        user_message = f"""
            TRANSCRIPT: {transcript}
            FACE: {deepface_data}
            """
        self.conversation_history.append({
            "role": "user",
            "content": user_message
        })
        start = time.time()
        response = ollama.chat(
            model=self.model,
            messages=self.conversation_history
            #format=EmotionResponse.model_json_schema()
        )
        elapsed = time.time() - start
        print(f"{self.model} response time: {elapsed:.2f} seconds")

        assistant_reply = response["message"]["content"]

        # Append assistant reply to history so context is maintained
        self.conversation_history.append({
            "role": "assistant",
            "content": assistant_reply
        })

        return assistant_reply
    
    def reset(self):
        """Reset conversation but keep the system prompt"""
        self.conversation_history = [
            {"role": "system", "content": COMPACT_PROMPT}
        ]


if __name__ == "__main__":
    import statistics

    user_said = "What is your name?"
    deep_face_data = {'counts': {'neutral': 24}, 'averages': {'angry': 0.02655, 'disgust': 0.0, 'fear': 0.0005833333333333332, 'happy': 0.0018666666666666666, 'sad': 0.027316666666666666, 'surprise': 1.6666666666666667e-05, 'neutral': 0.9436333333333331}, 'peaks': {'angry': 0.1295, 'disgust': 0.0, 'fear': 0.0029, 'happy': 0.0097, 'sad': 0.0953, 'surprise': 0.0001, 'neutral': 0.9966}}

    NUM_RUNS = 20
    WARMUP = 2
    bot = EmotionalBot()

    # --- TEST 1: Single turn (reset between runs) ---
    print("\n=== TEST 1: Single turn (no history) ===")
    print(f"Warming up...")
    for _ in range(WARMUP):
        bot.chat(user_said, deep_face_data)
        bot.reset()

    times = []
    for i in range(NUM_RUNS):
        bot.reset()
        start = time.time()
        bot.chat(user_said, deep_face_data)
        elapsed = time.time() - start
        times.append(elapsed)
        print(f"  Run {i+1:02d}: {elapsed:.2f}s")

    print(f"\nModel: {bot.model}")
    print(f"Mean:   {sum(times)/len(times):.2f}s")
    print(f"Min:    {min(times):.2f}s")
    print(f"Max:    {max(times):.2f}s")
    print(f"StdDev: {statistics.stdev(times):.2f}s")

    # --- TEST 2: Multi-turn (growing history) ---
    print("\n=== TEST 2: Multi-turn (growing history) ===")
    bot.reset()
    for i in range(10):
        start = time.time()
        bot.chat(user_said, deep_face_data)
        elapsed = time.time() - start
        print(f"  Turn {i+1:02d} (history size {len(bot.conversation_history)}): {elapsed:.2f}s")
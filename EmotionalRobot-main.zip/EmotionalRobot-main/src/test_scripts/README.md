# QT Robot LLM Evaluation Scripts

All scripts test every model defined in `eval_config.py`. To add or remove models, edit the `MODELS` list there.

## Files

| File | Test | Automated? |
|------|------|------------|
| `eval_config.py` | Shared config, models, prompt, helpers | — |
| `test_format_compliance.py` | Does the model output MISMATCH:/RESPONSE: every time? | Yes |
| `test_instruction_following.py` | Are gestures/expressions valid and emotionally appropriate? | Yes |
| `test_mismatch_detection.py` | Does the model correctly detect face/transcript conflicts? | Yes |
| `test_response_length.py` | Are responses concise and consistent in length? | Yes |
| `test_robustness.py` | Does the model handle garbled/incomplete transcripts? | Yes |
| `test_response_appropriateness.py` | Are responses natural and empathetic? | Human-rated |

## How to run

Make sure `eval_config.py` is in the same directory, then:

```bash
python3 test_format_compliance.py
python3 test_instruction_following.py
python3 test_mismatch_detection.py
python3 test_response_length.py
python3 test_robustness.py
python3 test_response_appropriateness.py   # interactive — you rate responses
```

## Notes

- `test_response_appropriateness.py` is interactive. It prints each response and asks you to rate it 1–5. Results are saved to `response_appropriateness_results.txt`.
- All scripts import from `eval_config.py` — keep it in the same folder.
- The first call per model in a session may be slower (model loading) — this is normal.
